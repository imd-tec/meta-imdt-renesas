/**
 * @file web_socket_frame_builder.cpp
 * @copyright Copyright (c) 2022 IMD Technologies. All rights reserved.
 * @author Paul Thomson <pault@imd-tec.com>
 */

#include "http_server/web_socket_frame_builder.hpp"
#include "http_server/web_socket_constants.hpp"

#include <unistd.h>

#include <cstring>
#include <climits>
#include <iostream>

using namespace http_server;

/**
 *
 */
WebSocketFrameBuilder::WebSocketFrameBuilder(const uint8_t opcode):
    _opcode(opcode)
{
}

/**
 *
 */
void WebSocketFrameBuilder::SetPayload(const std::vector<uint8_t>& payload)
{
    _payload = payload;
}

/**
 * @todo This will be inefficient for very large payloads
 */
void WebSocketFrameBuilder::SetPayload(const std::string& payload)
{
    _payload.clear();

    for (auto c : payload)
    {
        _payload.push_back(c);
    }
}

/**
 *
 * 0                   1                   2                   3
 * 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1
 * +-+-+-+-+-------+-+-------------+-------------------------------+
 * |F|R|R|R| opcode|M| Payload len |    Extended payload length    |
 * |I|S|S|S|  (4)  |A|     (7)     |             (16/64)           |
 * |N|V|V|V|       |S|             |   (if payload len==126/127)   |
 * | |1|2|3|       |K|             |                               |
 * +-+-+-+-+-------+-+-------------+ - - - - - - - - - - - - - - - +
 * |     Extended payload length continued, if payload len == 127  |
 * + - - - - - - - - - - - - - - - +-------------------------------+
 * |                               |Masking-key, if MASK set to 1  |
 * +-------------------------------+-------------------------------+
 * | Masking-key (continued)       |          Payload Data         |
 * +-------------------------------- - - - - - - - - - - - - - - - +
 * :                     Payload Data continued ...                :
 * + - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - +
 * |                     Payload Data continued ...                |
 * +---------------------------------------------------------------+
 *
 */
void WebSocketFrameBuilder::SendFrame(SocketFileDescriptorSPtr client_fd)
{
    uint8_t header[14];
    memset(header, 0, sizeof(header));

    size_t header_length = 0;

    header[header_length++] = (1 << 7) | _opcode;

    uint64_t payload_length = _payload.size();

    if (payload_length < kTwoBytePayloadLengthMarker)
    {
        header[header_length++] = static_cast<uint8_t>(payload_length & 0xFF);
    }
    else if (payload_length <= UINT16_MAX)
    {
        header[header_length++] = kTwoBytePayloadLengthMarker;
        header[header_length++] = static_cast<uint8_t>((payload_length >> 8) & 0xFF);
        header[header_length++] = static_cast<uint8_t>(payload_length & 0xFF);
    }
    else
    {
        header[header_length++] = kEightBytePayloadLengthMarker;
        header[header_length++] = static_cast<uint8_t>((payload_length >> 56) & 0xFF);
        header[header_length++] = static_cast<uint8_t>((payload_length >> 48) & 0xFF);
        header[header_length++] = static_cast<uint8_t>((payload_length >> 40) & 0xFF);
        header[header_length++] = static_cast<uint8_t>((payload_length >> 32) & 0xFF);
        header[header_length++] = static_cast<uint8_t>((payload_length >> 24) & 0xFF);
        header[header_length++] = static_cast<uint8_t>((payload_length >> 16) & 0xFF);
        header[header_length++] = static_cast<uint8_t>((payload_length >> 8) & 0xFF);
        header[header_length++] = static_cast<uint8_t>(payload_length & 0xFF);
    }

    auto length = write(client_fd->Get(), header, header_length);
    (void) length;
    length = write(client_fd->Get(), _payload.data(), payload_length);
    (void) length;
}
