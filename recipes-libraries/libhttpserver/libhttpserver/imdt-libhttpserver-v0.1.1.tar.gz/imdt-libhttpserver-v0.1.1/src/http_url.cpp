/**
 * @file http_url.cpp
 * @copyright Copyright (c) 2022 IMD Technologies. All rights reserved.
 * @author Paul Thomson <pault@imd-tec.com>
 */

#include "http_server/http_url.hpp"

#include <iostream>

using namespace http_server;

/*
 *
 *
 *
 */

/**
 *
 */
HttpUrl::HttpUrl()
{
}

/**
 *
 */
HttpUrl::HttpUrl(const std::string& url)
{
    ParseUrl(url);
}

/**
 *
 */
void HttpUrl::SetUrl(const std::string& url)
{
    ParseUrl(url);
}

/*
 *
 *
 *
 */

/**
 *
 */
void HttpUrl::ParseUrl(const std::string& url)
{
    _full_url = url;

    // Extract the "route"; everything up to the next "/", the "?" or the end of the URL

    if (_full_url.size() > 1)
    {
        auto end_of_route = _full_url.find("/", 1);

        if (std::string::npos == end_of_route)
        {
            end_of_route = _full_url.find("?");
        }

        _route = _full_url.substr(0, end_of_route);
    }

    _is_valid = true;
}
