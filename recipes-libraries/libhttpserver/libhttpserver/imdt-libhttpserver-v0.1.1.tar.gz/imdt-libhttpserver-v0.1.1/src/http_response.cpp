/**
 * @file http_response.cpp
 * @copyright Copyright (c) 2022 IMD Technologies. All rights reserved.
 * @author Paul Thomson <pault@imd-tec.com>
 */

#include "http_server/http_response.hpp"

#include <unistd.h>

#include <sstream>
#include <cstring>
#include <ctime>
#include <iostream>
#include <vector>
#include <fstream>

using namespace http_server;

/*
 *
 *
 *
 */

/**
 *
 */
HttpResponse::HttpResponse(SocketFileDescriptorSPtr client_fd):
    _client_fd(client_fd),
    _status_code(HttpStatusCode::k200OK),
    _content_type(MIMEContentType::kTextHTML)
{
}

/**
 *
 */
void HttpResponse::SetStatusCode(HttpStatusCode status_code)
{
    _status_code = status_code;
}

/**
 *
 */
void HttpResponse::SetContentType(MIMEContentType content_type)
{
    _content_type = content_type;
}

/**
 *
 */
void HttpResponse::AddHeaderField(const std::string& header,
                                  const std::string& value)
{
    _header_fields[header] = value;
}

/**
 * @todo Warn/error if content has already been set
 */
void HttpResponse::SetContent(const std::string& content)
{
    _text_content << content;
    _source_type = ContentSourceType::Text;
    _content_length = content.size();
}

/**
 * @todo Warn/error if content has already been set
 */
void HttpResponse::SetContent(const std::filesystem::path& file_path)
{
    _file_content_path = file_path;
    _source_type = ContentSourceType::File;
    _content_length = std::filesystem::file_size(file_path);
}

/**
 *
 */
void HttpResponse::SendToClient()
{
    std::stringstream response;

    auto status_number_reason = _status_code_table.find(_status_code);
    auto status_number = std::get<0>(status_number_reason->second);
    auto status_reason = std::get<1>(status_number_reason->second);

    response << "HTTP/1.1 " << status_number << " " << status_reason << "\r\n";

    const std::time_t now = std::time(nullptr);
    char date_time_buffer[128];

    if (strftime(date_time_buffer, sizeof(date_time_buffer), "%a, %d %b %Y %H:%M:%S %Z", std::localtime(&now)))
    {
        response << "Date: " << date_time_buffer << "\r\n";
    }

    response << "Content-Length: " << _content_length << "\r\n";

    if (_content_length > 0)
    {
        auto content_type = _content_type_table.find(_content_type);
        response << "Content-Type: " << content_type->second << "\r\n";
    }

    for (auto fv : _header_fields)
    {
        response << fv.first << ": " << fv.second << "\r\n";
    }

    response << "\r\n";

    auto length = write(_client_fd->Get(), response.str().c_str(), response.str().size());
    (void) length;

    if (_content_length > 0)
    {
        switch (_source_type)
        {
            case ContentSourceType::File:
            {
                std::ifstream source_file(_file_content_path);
                std::vector<char> buffer(4096);

                while (!source_file.eof())
                {
                    source_file.read(buffer.data(), buffer.size());
                    std::streamsize s = source_file.gcount();

                    auto length = write(_client_fd->Get(), buffer.data(), s);
                    (void) length;
                }

                break;
            }

            case ContentSourceType::Text:
            {
                auto length = write(_client_fd->Get(), _text_content.str().c_str(), _text_content.str().size());
                (void) length;

                break;
            }

            case ContentSourceType::Invalid:
            {
                /// @todo Warn/error
                break;
            }
        }
    }
}

/*
 *
 *
 *
 */

std::map<HttpStatusCode, HttpResponse::StatusNumberReason> HttpResponse::_status_code_table =
{
    { HttpStatusCode::k100Continue,                      { 100, "Continue" } },
    { HttpStatusCode::k101SwitchingProtocols,            { 101, "Switching Protocols" } },
    { HttpStatusCode::k102Processing,                    { 102, "Processing" } },
    { HttpStatusCode::k103EarlyHints,                    { 103, "Early Hints" } },
    { HttpStatusCode::k200OK,                            { 200, "OK" } },
    { HttpStatusCode::k201Created,                       { 201, "Created" } },
    { HttpStatusCode::k202Accepted,                      { 202, "Accepted" } },
    { HttpStatusCode::k203NonAuthoritativeInformation,   { 203, "Non-Authoritative Information" } },
    { HttpStatusCode::k204NoContent,                     { 204, "No Content" } },
    { HttpStatusCode::k205ResetContent,                  { 205, "Reset Content" } },
    { HttpStatusCode::k206PartialContent,                { 206, "Partial Content" } },
    { HttpStatusCode::k207MultiStatus,                   { 207, "Multi-Status" } },
    { HttpStatusCode::k208AlreadyReported,               { 208, "Already Reported" } },
    { HttpStatusCode::k226IMUsed,                        { 226, "IM Used" } },
    { HttpStatusCode::k300MultipleChoices,               { 300, "Multiple Choices" } },
    { HttpStatusCode::k301MovedPermanently,              { 301, "Moved Permanently" } },
    { HttpStatusCode::k302Found,                         { 302, "Found" } },
    { HttpStatusCode::k303SeeOther,                      { 303, "See Other" } },
    { HttpStatusCode::k304NotModified,                   { 304, "Not Modified" } },
    { HttpStatusCode::k305UseProxy,                      { 305, "Use Proxy" } },
    { HttpStatusCode::k306SwitchProxy,                   { 306, "Switch Proxy" } },
    { HttpStatusCode::k307TemporaryRedirect,             { 307, "Temporary Redirect" } },
    { HttpStatusCode::k308PermanentRedirect,             { 308, "Permanent Redirect" } },
    { HttpStatusCode::k400BadRequest,                    { 400, "Bad Request" } },
    { HttpStatusCode::k401Unauthorized,                  { 401, "Unauthorized" } },
    { HttpStatusCode::k402PaymentRequired,               { 402, "Payment Required" } },
    { HttpStatusCode::k403Forbidden,                     { 403, "Forbidden" } },
    { HttpStatusCode::k404NotFound,                      { 404, "Not Found" } },
    { HttpStatusCode::k405MethodNotAllowed,              { 405, "Method Not Allowed" } },
    { HttpStatusCode::k406NotAcceptable,                 { 406, "Not Acceptable" } },
    { HttpStatusCode::k407ProxyAuthenticationRequired,   { 407, "Proxy Authentication Required" } },
    { HttpStatusCode::k408RequestTimeout,                { 408, "Request Timeout" } },
    { HttpStatusCode::k409Conflict,                      { 409, "Conflict" } },
    { HttpStatusCode::k410Gone,                          { 410, "Gone" } },
    { HttpStatusCode::k411LengthRequired,                { 411, "Length Required" } },
    { HttpStatusCode::k412PreconditionFailed,            { 412, "Precondition Failed" } },
    { HttpStatusCode::k413PayloadTooLarge,               { 413, "Payload Too Large" } },
    { HttpStatusCode::k414URITooLong,                    { 414, "URI Too Long" } },
    { HttpStatusCode::k415UnsupportedMediaType,          { 415, "Unsupported Media Type" } },
    { HttpStatusCode::k416RangeNotSatisfiable,           { 416, "Range Not Satisfiable" } },
    { HttpStatusCode::k417ExpectationFailed,             { 417, "Expectation Failed" } },
    { HttpStatusCode::k418ImATeapot,                     { 418, "I'm A Teapot" } },
    { HttpStatusCode::k421MisdirectedRequest,            { 421, "Misdirected Request" } },
    { HttpStatusCode::k422UnprocessableEntity,           { 422, "Unprocessable Entity" } },
    { HttpStatusCode::k423Locked,                        { 423, "Locked" } },
    { HttpStatusCode::k424FailedDependency,              { 424, "Failed Dependency" } },
    { HttpStatusCode::k425TooEarly,                      { 425, "Too Early" } },
    { HttpStatusCode::k426UpgradeRequired,               { 426, "Upgrade Required" } },
    { HttpStatusCode::k428PreconditionRequired,          { 428, "Precondition Required" } },
    { HttpStatusCode::k429TooManyRequests,               { 429, "Too Many Requests" } },
    { HttpStatusCode::k431RequestHeaderFieldsTooLarge,   { 431, "Request Header Fields Too Large" } },
    { HttpStatusCode::k451UnavailableForLegalReasons,    { 451, "Unavailable For Legal Reasons" } },
    { HttpStatusCode::k500InternalServerError,           { 500, "Internal Server Error" } },
    { HttpStatusCode::k501NotImplemented,                { 501, "Not Implemented" } },
    { HttpStatusCode::k502BadGateway,                    { 502, "Bad Gateway" } },
    { HttpStatusCode::k503ServiceUnavailable,            { 503, "Service Unavailable" } },
    { HttpStatusCode::k504GatewayTimeout,                { 504, "Gateway Timeout" } },
    { HttpStatusCode::k505HTTPVersionNotSupported,       { 505, "HTTP Version Not Supported" } },
    { HttpStatusCode::k506VariantAlsoNegotiates,         { 506, "Variant Also Negotiates" } },
    { HttpStatusCode::k507InsufficientStorage,           { 507, "Insufficient Storage" } },
    { HttpStatusCode::k508LoopDetected,                  { 508, "Loop Detected" } },
    { HttpStatusCode::k510NotExtended,                   { 510, "Not Extended" } },
    { HttpStatusCode::k511NetworkAuthenticationRequired, { 511, "Network Authentication Required" } },
};

std::map<MIMEContentType, std::string> HttpResponse::_content_type_table =
{
    { MIMEContentType::kApplicationJavascript, "application/javascript" },
    { MIMEContentType::kApplicationOctetStream, "application/octet-stream" },
    { MIMEContentType::kImageJPEG, "image/jpeg" },
    { MIMEContentType::kImagePNG, "image/png" },
    { MIMEContentType::kImageSVGXML, "image/svg+xml" },
    { MIMEContentType::kImageXIcon, "image/x-icon" },
    { MIMEContentType::kTextCSS, "text/css" },
    { MIMEContentType::kTextHTML, "text/html" },
};
