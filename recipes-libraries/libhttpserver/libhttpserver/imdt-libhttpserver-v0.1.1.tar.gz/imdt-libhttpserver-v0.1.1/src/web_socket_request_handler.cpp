/**
 * @file web_socket_request_handler.cpp
 * @copyright Copyright (c) 2022 IMD Technologies. All rights reserved.
 * @author Paul Thomson <pault@imd-tec.com>
 */

#include "http_server/web_socket_request_handler.hpp"
#include "http_server/web_socket_frame_parser.hpp"
#include "http_server/web_socket_frame_builder.hpp"
#include "http_server/web_socket_constants.hpp"

#include <openssl/sha.h>
#include <openssl/evp.h>

#include <glog/logging.h>

#include <netinet/in.h>
#include <sys/select.h>
#include <unistd.h>

#include <cstring>
#include <climits>
#include <iostream>

using namespace http_server;

/*
 *
 *
 *
 */

/**
 *
 */
WebSocketRequestHandler::~WebSocketRequestHandler()
{
}

/**
 *
 */
void WebSocketRequestHandler::HandleRequest(const HttpRequest& request,
                                            HttpResponse& response)
{
    // Perform the handshake

    std::string guid = "258EAFA5-E914-47DA-95CA-C5AB0DC85B11";
    std::string web_socket_key = request.RequestHeaders().find("Sec-WebSocket-Key")->second;

    std::string t = web_socket_key + guid;

    uint8_t hash[SHA_DIGEST_LENGTH];

    SHA1(reinterpret_cast<uint8_t const *>(t.c_str()), t.size(), hash);

    const auto pl = 4*((SHA_DIGEST_LENGTH+2)/3);
    auto output = reinterpret_cast<char *>(calloc(pl+1, 1)); //+1 for the terminating null that EVP_EncodeBlock adds on
    const auto ol = EVP_EncodeBlock(reinterpret_cast<unsigned char *>(output), hash, SHA_DIGEST_LENGTH);
    (void) ol;

    response.SetStatusCode(HttpStatusCode::k101SwitchingProtocols);
    response.AddHeaderField("Upgrade", "websocket");
    response.AddHeaderField("Connection", "Upgrade");
    response.AddHeaderField("Sec-WebSocket-Accept", output);

    response.SendToClient();

    // Listen for WebSocket messages

    SocketFileDescriptorSPtr client_fd = response.ClientFd();

    while (true)
    {
        fd_set fds;

        FD_ZERO(&fds);
        FD_SET(client_fd->Get(), &fds);

        int r = select(client_fd->Get() + 1, &fds, NULL, NULL, NULL);

        if (r < 0)
        {
            LOG(ERROR) << "Error...";
            return;
        }

        WebSocketFrameParser frame_parser(client_fd);

        try
        {
            frame_parser.ReceiveFrame();
        }
        catch (WebSocketFrameParserException& e)
        {
            // Client has hung up or sent bad data, so close the connection

            return;
        }

        if (ws_opcode::kConnectionClose == frame_parser.Opcode())
        {
            // Acknowledge close request

            WebSocketFrameBuilder frame_builder(ws_opcode::kConnectionClose);
            frame_builder.SendFrame(frame_parser.ClientFd());

            return;
        }

        bool keep_alive = ProcessWebSocketFrame(frame_parser);

        if (false == keep_alive)
        {
            // Close the connection

            WebSocketFrameBuilder frame_builder(ws_opcode::kConnectionClose);
            frame_builder.SendFrame(frame_parser.ClientFd());

            return;
        }
    }
}
