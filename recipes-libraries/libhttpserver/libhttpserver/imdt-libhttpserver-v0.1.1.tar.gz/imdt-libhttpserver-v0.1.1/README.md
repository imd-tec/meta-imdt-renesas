# HTTP Server Shared Library

* Shared library written in C++17
* Implements an HTTP server, with support for the WebSocket API
* Includes a static file server, with support for HTML, CSS, JavaScript and JPG and PNG images
* Example server shows how to receive and send WebSocket frames
