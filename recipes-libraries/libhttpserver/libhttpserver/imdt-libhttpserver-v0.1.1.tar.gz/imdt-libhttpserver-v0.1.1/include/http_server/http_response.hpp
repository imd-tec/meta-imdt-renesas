/**
 * @file http_response.hpp
 * @copyright Copyright (c) 2022 IMD Technologies. All rights reserved.
 * @author Paul Thomson <pault@imd-tec.com>
 */

#pragma once

#include "http_server/socket_file_descriptor.hpp"

#include <map>
#include <sstream>
#include <string>
#include <filesystem>

namespace http_server
{
    enum class HttpStatusCode;
    enum class MIMEContentType;

    /**
     * @brief Builds HTTP responses and sends them to the client
     */
    class HttpResponse
    {
    public:

        /**
         * @brief Constructor
         * @param client_fd Client connection file descriptor
         */
        explicit HttpResponse(SocketFileDescriptorSPtr client_fd);

        /**
         * @brief Set the status code
         * @param status_code Enumerated status code
         */
        void SetStatusCode(HttpStatusCode status_code);

        /**
         * @brief Set the content type
         * @param content_type Enumerated content type
         */
        void SetContentType(MIMEContentType content_type);

        /**
         * @brief Add a header field
         * @param header The header field (e.g., "Upgrade")
         * @param value The header value (e.g., "websocket")
         */
        void AddHeaderField(const std::string& header,
                            const std::string& value);

        /**
         * @brief Add a string to the response
         * @param content Text content
         */
        void SetContent(const std::string& text_content);

        /**
         * @brief Add an entire file to the response
         * @param file_path Path to the file
         */
        void SetContent(const std::filesystem::path& file_path);

        /**
         * @brief Construct the response and send it to the client
         */
        void SendToClient();

        /**
         * @brief Access the client connection file descriptor
         * @return File descriptor
         */
        SocketFileDescriptorSPtr ClientFd() const;

    private:

        /// @brief Client connection file descriptor
        SocketFileDescriptorSPtr _client_fd;

        /// @brief Enumerated HTTP status code
        HttpStatusCode _status_code;

        /// @brief Map of header fields and values
        std::map<std::string, std::string> _header_fields;

        /// @brief Enumerated MIME content type
        MIMEContentType _content_type;

        enum class ContentSourceType
        {
            Invalid, Text, File
        };

        ContentSourceType _source_type { ContentSourceType::Invalid };

        /// @brief Text content
        std::stringstream _text_content;

        /// @brief Path to the source file
        std::filesystem::path _file_content_path;

        /// @brief Content length, in bytes
        size_t _content_length { 0 };

        using StatusNumberReason = std::tuple<uint16_t, std::string>;

        /// @brief Map of HTTP status codes and reasons
        static std::map<HttpStatusCode, StatusNumberReason> _status_code_table;

        /// @brief Map of MIME content types and their string descriptions
        static std::map<MIMEContentType, std::string> _content_type_table;

    };

    inline
    SocketFileDescriptorSPtr HttpResponse::ClientFd() const
    {
        return _client_fd;
    }

    enum class HttpStatusCode
    {
        k100Continue,
        k101SwitchingProtocols,
        k102Processing,
        k103EarlyHints,

        k200OK,
        k201Created,
        k202Accepted,
        k203NonAuthoritativeInformation,
        k204NoContent,
        k205ResetContent,
        k206PartialContent,
        k207MultiStatus,
        k208AlreadyReported,
        k226IMUsed,

        k300MultipleChoices,
        k301MovedPermanently,
        k302Found,
        k303SeeOther,
        k304NotModified,
        k305UseProxy,
        k306SwitchProxy,
        k307TemporaryRedirect,
        k308PermanentRedirect,

        k400BadRequest,
        k401Unauthorized,
        k402PaymentRequired,
        k403Forbidden,
        k404NotFound,
        k405MethodNotAllowed,
        k406NotAcceptable,
        k407ProxyAuthenticationRequired,
        k408RequestTimeout,
        k409Conflict,
        k410Gone,
        k411LengthRequired,
        k412PreconditionFailed,
        k413PayloadTooLarge,
        k414URITooLong,
        k415UnsupportedMediaType,
        k416RangeNotSatisfiable,
        k417ExpectationFailed,
        k418ImATeapot,
        k421MisdirectedRequest,
        k422UnprocessableEntity,
        k423Locked,
        k424FailedDependency,
        k425TooEarly,
        k426UpgradeRequired,
        k428PreconditionRequired,
        k429TooManyRequests,
        k431RequestHeaderFieldsTooLarge,
        k451UnavailableForLegalReasons,

        k500InternalServerError,
        k501NotImplemented,
        k502BadGateway,
        k503ServiceUnavailable,
        k504GatewayTimeout,
        k505HTTPVersionNotSupported,
        k506VariantAlsoNegotiates,
        k507InsufficientStorage,
        k508LoopDetected,
        k510NotExtended,
        k511NetworkAuthenticationRequired,
    };

    enum class MIMEContentType
    {
        kApplicationJavascript,
        kApplicationOctetStream,
        kImageJPEG,
        kImagePNG,
        kImageSVGXML,
        kImageXIcon,
        kTextCSS,
        kTextHTML
    };
}
