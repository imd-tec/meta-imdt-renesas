/**
 * @file socket_file_descriptor.hpp
 * @copyright Copyright (c) 2022 IMD Technologies. All rights reserved.
 * @author Paul Thomson <pault@imd-tec.com>
 */

#pragma once

#include <memory>

namespace http_server
{
    class SocketFileDescriptor;
    using SocketFileDescriptorSPtr = std::shared_ptr<SocketFileDescriptor>;

    /**
     * @brief Wrapper for a socket file descriptor
     */
    class SocketFileDescriptor
    {
    public:

        /**
         * @brief Constructor
         * @param fd Raw file descriptor
         */
        explicit SocketFileDescriptor(const int fd);

        /**
         * @brief Access the file descriptor
         * @return
         */
        int Get() const;

        /**
         * @brief Test the file descriptor to see if it's valid
         * @return
         */
        bool IsValid() const;

        /**
         * @brief Invalidate the file descriptor (e.g., after it's been closed)
         */
        void Invalidate();

    private:

        static constexpr int InvalidFileDescriptor { -1 };

        /// @brief Raw file descriptor
        int _fd { InvalidFileDescriptor };

    };

    inline
    SocketFileDescriptor::SocketFileDescriptor(const int fd):
        _fd(fd)
    {
    }

    inline
    int SocketFileDescriptor::Get() const
    {
        return _fd;
    }

    inline
    bool SocketFileDescriptor::IsValid() const
    {
        return (InvalidFileDescriptor != _fd);
    }

    inline
    void SocketFileDescriptor::Invalidate()
    {
        _fd = InvalidFileDescriptor;
    }
}
