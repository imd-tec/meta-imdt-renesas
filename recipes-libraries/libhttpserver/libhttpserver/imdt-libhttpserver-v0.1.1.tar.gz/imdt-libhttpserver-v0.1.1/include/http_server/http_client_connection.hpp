/**
 * @file http_client_connection.hpp
 * @copyright Copyright (c) 2022 IMD Technologies. All rights reserved.
 * @author Paul Thomson <pault@imd-tec.com>
 */

#pragma once

#include "http_server/http_server.hpp"
#include "http_server/socket_file_descriptor.hpp"

#include <netinet/in.h>

namespace http_server
{
    /**
     * @brief Start a new thread to handle the client connection
     * @param server HTTP server shared_ptr
     * @param client_fd Client connection file descriptor
     * @param client_address Client address information
     */
    void StartClientConnection(HttpServerSPtr server,
                               SocketFileDescriptorSPtr client_fd,
                               struct sockaddr_in client_address);

    /**
     * @brief Receive data from the client and process the requests
     */
    class HttpClientConnection
    {
    public:

        /**
         * @brief Constructor
         * @param server HTTP server shared_ptr
         * @param client_fd Client connection file descriptor
         */
        HttpClientConnection(HttpServerSPtr server,
                             SocketFileDescriptorSPtr client_fd);

        /**
         * @brief Receive requests from the client and send them to the server
         */
        void Run();

    private:

        /// @brief HTTP server
        HttpServerSPtr _server;

        /// @brief Client connection file descriptor
        SocketFileDescriptorSPtr _client_fd;

    };
}
