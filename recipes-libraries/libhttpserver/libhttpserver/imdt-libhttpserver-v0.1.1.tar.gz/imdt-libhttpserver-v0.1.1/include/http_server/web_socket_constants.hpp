/**
 * @file web_socket_constants.hpp
 * @copyright Copyright (c) 2022 IMD Technologies. All rights reserved.
 * @author Paul Thomson <pault@imd-tec.com>
 */

#pragma once

#include <cstdint>

namespace http_server
{
    namespace ws_opcode
    {
        static constexpr uint8_t kContinuationFrame { 0x0 };
        static constexpr uint8_t kTextFrame         { 0x1 };
        static constexpr uint8_t kBinaryFrame       { 0x2 };
        static constexpr uint8_t kConnectionClose   { 0x8 };
        static constexpr uint8_t kPing              { 0x9 };
        static constexpr uint8_t kPong              { 0xA };
    }

    static constexpr uint8_t kTwoBytePayloadLengthMarker    { 126 };
    static constexpr uint8_t kEightBytePayloadLengthMarker  { 127 };
}
