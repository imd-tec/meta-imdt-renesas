/**
 * @file http_request.hpp
 * @copyright Copyright (c) 2022 IMD Technologies. All rights reserved.
 * @author Paul Thomson <pault@imd-tec.com>
 */

#pragma once

#include "http_server/http_url.hpp"

#include <string>
#include <map>

namespace http_server
{
    using HttpRequestHeaders = std::map<std::string, std::string>;

    /**
     * @brief Parser and wrapper for HTTP requests
     */
    class HttpRequest
    {
    public:

        /**
         * @brief Constructor
         * @param http_request Raw HTTP request
         */
        explicit HttpRequest(const std::string& http_request);

        /**
         * @brief Returns the request method (GET, POST, etc)
         * @return Request method
         */
        const std::string& RequestMethod() const;

        /**
         * @brief Returns the parsed request URL
         * @return Request URL object
         */
        const HttpUrl& RequestURL() const;

        /**
         * @brief Returns the protocol version
         * @return Protocol version (e.g., "HTTP/1.1")
         */
        const std::string& ProtocolVersion() const;

        /**
         * @brief Returns a map of the request headers
         * @return
         */
        const HttpRequestHeaders& RequestHeaders() const;

    private:

        /**
         * @brief Extract the method, URL and version from the request line
         * @param request_line Raw request line
         */
        void ParseRequestLine(const std::string& request_line);

        /// @brief The request method (e.g., "GET", "POST")
        std::string _request_method;

        /// @brief The request URL
        HttpUrl _request_url;

        /// @brief The protocol version (e.g., "HTTP/1.1")
        std::string _protocol_version;

        /// @brief Map of header fields and values
        HttpRequestHeaders _header_values;
    };

    inline
    const std::string& HttpRequest::RequestMethod() const
    {
        return _request_method;
    }

    inline
    const HttpUrl& HttpRequest::RequestURL() const
    {
        return _request_url;
    }

    inline
    const std::string& HttpRequest::ProtocolVersion() const
    {
        return _protocol_version;
    }

    inline
    const HttpRequestHeaders& HttpRequest::RequestHeaders() const
    {
        return _header_values;
    }
}
