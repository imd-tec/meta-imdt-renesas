/**
 * @file http_request_handler.hpp
 * @copyright Copyright (c) 2022 IMD Technologies. All rights reserved.
 * @author Paul Thomson <pault@imd-tec.com>
 */

#pragma once

#include "http_server/http_request.hpp"
#include "http_server/http_response.hpp"

#include <memory>

namespace http_server
{
    class HttpRequestHandler;
    using HttpRequestHandlerSPtr = std::shared_ptr<HttpRequestHandler>;

    /**
     * @brief Abstract base class for request handlers
     */
    class HttpRequestHandler
    {
    public:

        /**
         * @brief Virtual destructor
         */
        virtual ~HttpRequestHandler();

        /**
         * @brief Handle a request from a client
         * @param request HTTP request
         * @param response Container for the response
         */
        virtual void HandleRequest(const HttpRequest& request,
                                   HttpResponse& response) = 0;

    };
}
